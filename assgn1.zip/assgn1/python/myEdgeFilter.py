import numpy as np
from scipy import signal    # For signal.gaussian function

from myImageFilter import myImageFilter

def myEdgeFilter(img0, sigma):
    # YOUR CODE HERE
