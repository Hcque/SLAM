import numpy as np
import cv2  # For cv2.dilate function

def myHoughLines(H, nLines):
    # YOUR CODE HERE
