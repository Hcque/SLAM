import numpy as np
import cv2
import skimage.io 
import skimage.color
#Import necessary functions



#Write script for Q3.9
