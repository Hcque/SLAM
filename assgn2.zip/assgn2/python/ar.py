import numpy as np
import cv2
#Import necessary functions





#Write script for Q4.1
