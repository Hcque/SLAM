import numpy as np
import cv2
from matchPics import matchPics


#Q3.5
#Read the image and convert to grayscale, if necessary

for i in range(36):
	#Rotate Image
	
	#Compute features, descriptors and Match features

	#Update histogram


#Display histogram

